Thanks a lot for your detailed and useful report\! I am sorry for the delay; my “real” job has been keeping me very busy.

Version 1.3.0.9017 on Github should fix the issue. Please let me know if it works for you.

``` r
library(modelsummary)
tmp <- transform(mtcars, a_b = qsec, b_c = hp)
panels <- list(
"Panel B: $\\log(3)^2$" = list(
    "A_B" = lm(mpg ~ a_b, data = tmp),
    "B_C" = lm(mpg ~ a_b + b_c, data = tmp)),
"Panel B: $\\log(3)_2$" = list(
    "A_B" = lm(disp ~ a_b, data = tmp),
    "B_C" = lm(disp ~ a_b + b_c, data = tmp))
)
modelsummary(panels, output = "latex_tabular", shape = "rbind", title = "$\\beta_1$", escape = FALSE)
# \begin{table}
# 
# \caption{\label{tab:unnamed-chunk-2}$\beta_1$}
# \centering
# \begin{tabular}[t]{lcc}
# \toprule
#   & A_B & B_C\\
# \midrule
# \addlinespace[0.5em]
# \multicolumn{3}{l}{\textit{Panel B: $\log(3)^2$}}\\
# \midrule \hspace{1em}(Intercept) & -5.114 & 48.324\\
# \hspace{1em} & (10.030) & (11.103)\\
# \hspace{1em}a_b & 1.412 & -0.887\\
# \hspace{1em} & (0.559) & (0.535)\\
# \hspace{1em}b_c &  & -0.085\\
# \hspace{1em} &  & (0.014)\\
# \hspace{1em}Num.Obs. & 32 & \vphantom{1} 32\\
# \hspace{1em}R2 & 0.175 & 0.637\\
# \hspace{1em}R2 Adj. & 0.148 & 0.612\\
# \hspace{1em}AIC & 204.6 & 180.3\\
# \hspace{1em}BIC & 209.0 & 186.2\\
# \hspace{1em}Log.Lik. & -99.294 & -86.170\\
# \hspace{1em}F & 6.377 & 25.431\\
# \hspace{1em}RMSE & 5.39 & 3.57\\
# \addlinespace[0.5em]
# \multicolumn{3}{l}{\textit{Panel B: $\log(3)_2$}}\\
# \midrule \hspace{1em}(Intercept) & 767.619 & -340.780\\
# \hspace{1em} & (204.642) & (221.689)\\
# \hspace{1em}a_b & -30.080 & 17.599\\
# \hspace{1em} & (11.410) & (10.674)\\
# \hspace{1em}b_c &  & 1.755\\
# \hspace{1em} &  & (0.278)\\
# \hspace{1em}Num.Obs. & 32 & 32\\
# \hspace{1em}R2 & 0.188 & 0.658\\
# \hspace{1em}R2 Adj. & 0.161 & 0.634\\
# \hspace{1em}AIC & 397.6 & 372.0\\
# \hspace{1em}BIC & 402.0 & 377.8\\
# \hspace{1em}Log.Lik. & -195.797 & -181.979\\
# \hspace{1em}F & 6.950 & 27.859\\
# \hspace{1em}RMSE & 109.92 & 71.37\\
# \bottomrule
# \end{tabular}
# \end{table}
```
