structure(list(` ` = c("vs", "", "gear", "", ""), `  ` = c("FALSE", 
"TRUE", "3", "4", "5"), N = c("18", "14", "15", "12", "5"), `%` = c("56.2", 
"43.8", "46.9", "37.5", "15.6")), row.names = c(NA, -5L), class = "data.frame", stub_width = 2L, align = c("l", 
"l", "r", "r"), output_format = "dataframe")
