structure(list(` ` = c("mpg", "hp"), mpg = c("1", "-.78"), hp = c(".", 
"1")), row.names = c(NA, -2L), class = "data.frame", align = c("l", 
"r", "r"))
