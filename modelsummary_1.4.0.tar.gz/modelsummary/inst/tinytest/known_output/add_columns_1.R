structure(list(first = c("blah", "junk"), ` ` = c("mpg", "hp"
), mean = c("20.09", "146.69"), sd = c("6.03", "68.56"), last = c("2.00", 
"4.00")), class = "data.frame", row.names = c(NA, -2L), align = c("l", 
"r", "r", "r", "r"))
