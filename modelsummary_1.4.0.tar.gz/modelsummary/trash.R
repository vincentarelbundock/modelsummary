library(modelsummary)
library(tibble)
library(fixest)

# regression with fixest package
reg <- fixest::feols(
    c(mpg, hp) ~ sw(log(qsec), log(drat)) | gear + vs, data = mtcars
)

# grep panels 
panels_reg <- list(
    "Panel A. $\\log(qsec)_{gt}$" = reg[grepl("qsec", names(reg))],
    "Panel B. $\\Delta(drat)_{gt}$" = reg[grepl("qsec", names(reg))]
)

# some latex math mode for the coefficients 
coef_labels_reg <- rep(
        "$\\log({SO_{X}})_{g} \\times Post_{t}$",
    length(panels_reg[[1]])
)
names(coef_labels_reg) <- c("log(qsec)", "(logdrat)")

# adding some rows at the end (these are not escaped)
rows_reg <- tibble(
    a = c("\\hspace{1em}Gear FE", rep("$\\checkmark$", 2)),
    b = c("\\hspace{1em}VS FE", rep("$\\checkmark$", 2))
)
rows_reg <- data.frame(t(rows_reg))

# run modelsummary with `escape=FALSE` option on
Q
pkgload::load_all()
modelsummary::modelsummary(
    panels_reg,
    output = "latex_tabular",
    coef_map = coef_labels_reg,
    shape = "rbind",
    stars = c("*" = 0.1, "**" = 0.05, "***" = 0.01),
    col.names = NULL,
    add_rows = rows_reg,
    escape = FALSE
)
